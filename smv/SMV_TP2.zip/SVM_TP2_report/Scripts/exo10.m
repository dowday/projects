
clc;
close all;
X=rand(1000,1);
D = pdist(X);
figure; hist(D(:));



